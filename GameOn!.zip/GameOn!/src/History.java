
import java.awt.Color;
import java.awt.Font;
import java.awt.HeadlessException;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import javax.swing.event.DocumentListener;
import javax.swing.event.DocumentEvent;

public class History extends javax.swing.JFrame {

    private final String adminName;
    private final String gameMasterName;
    private final String playerName;
    private final String usname;
    private static final String FILE_PATH = "src/UserData.json"; // Correct file path

    public History(String adminName, String gameMasterName, String playerName, String usname) {
        this.adminName = adminName;
        this.gameMasterName = gameMasterName;
        this.playerName = playerName;
        this.usname = usname;
        initComponents();
        populateCategorySelection(); // Populate the combo box
        loadHistory(); // Load history data
        addSearchListener(); // Adds listener to search field for live updates
        
        HistoryTable.getTableHeader().setFont(new Font("ORC A Extended", Font.BOLD, 14));
        HistoryTable.getTableHeader().setOpaque(false);
        HistoryTable.getTableHeader().setBackground(new Color(102, 0, 255));
        HistoryTable.getTableHeader().setForeground(new Color(242, 242, 242));
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        HistoryTable = new javax.swing.JTable();
        BackButton = new javax.swing.JButton();
        SearchField = new javax.swing.JTextField();
        CategorySelection = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("OCR A Extended", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("History");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 50, -1, -1));

        HistoryTable.setBackground(new java.awt.Color(204, 153, 255));
        HistoryTable.setFont(new java.awt.Font("OCR A Extended", 1, 12)); // NOI18N
        HistoryTable.setForeground(new java.awt.Color(255, 255, 255));
        HistoryTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Player", "Title", "Category", "Score", "Result", "Timestamp"
            }
        ));
        HistoryTable.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                HistoryTableAncestorAdded(evt);
            }
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        jScrollPane1.setViewportView(HistoryTable);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 160, 615, 340));

        BackButton.setBackground(new java.awt.Color(102, 0, 255));
        BackButton.setFont(new java.awt.Font("OCR A Extended", 1, 24)); // NOI18N
        BackButton.setForeground(new java.awt.Color(255, 0, 51));
        BackButton.setText("<");
        BackButton.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        BackButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BackButtonActionPerformed(evt);
            }
        });
        jPanel1.add(BackButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 20, 130, 30));

        SearchField.setBackground(new java.awt.Color(102, 0, 255));
        SearchField.setFont(new java.awt.Font("OCR A Extended", 1, 12)); // NOI18N
        SearchField.setForeground(new java.awt.Color(255, 255, 255));
        SearchField.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        SearchField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SearchFieldActionPerformed(evt);
            }
        });
        jPanel1.add(SearchField, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 120, 212, 30));

        CategorySelection.setBackground(new java.awt.Color(102, 0, 255));
        CategorySelection.setFont(new java.awt.Font("OCR A Extended", 1, 12)); // NOI18N
        CategorySelection.setForeground(new java.awt.Color(255, 255, 255));
        CategorySelection.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "All", "Math", "Science", "History", "English" }));
        CategorySelection.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        CategorySelection.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CategorySelectionActionPerformed(evt);
            }
        });
        jPanel1.add(CategorySelection, new org.netbeans.lib.awtextra.AbsoluteConstraints(474, 120, 220, 30));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/GameOn! (Purple BG).png"))); // NOI18N
        jLabel2.setText("jLabel2");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 790, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void BackButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BackButtonActionPerformed
        try {
            // Check if adminName is not null or empty
            if (adminName != null && !adminName.isEmpty()) {
                // Navigate back to Administrator with adminName and usname
                new Administrator(adminName, usname).setVisible(true);
            } // Check if gameMasterName is not null or empty
            else if (gameMasterName != null && !gameMasterName.isEmpty()) {
                // Navigate back to GameMaster with gameMasterName and usname
                new GameMaster(gameMasterName, usname).setVisible(true);
            } // Check if playerName is not null or empty
            else if (playerName != null && !playerName.isEmpty()) {
                // Navigate back to Player with appropriate parameters
                new Player(playerName, "Player", 1, 2, "Player", usname).setVisible(true);
            } else {
                // Display an error message if no valid user type is found
                JOptionPane.showMessageDialog(this, "No valid user type found to navigate back.", "Error", JOptionPane.WARNING_MESSAGE);
            }
        } catch (HeadlessException e) {
            // Handle unexpected exceptions and provide feedback to the user
            JOptionPane.showMessageDialog(this, "Error navigating back: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        } finally {
            // Dispose the current frame to return to the previous one
            this.dispose();
        }
    }//GEN-LAST:event_BackButtonActionPerformed

    private void HistoryTableAncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_HistoryTableAncestorAdded
        // TODO add your handling code here:
    }//GEN-LAST:event_HistoryTableAncestorAdded

    private void SearchFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SearchFieldActionPerformed
        String keyword = SearchField.getText().trim();
        if (!keyword.isEmpty()) {
            searchHistory(keyword);
        } else {
            loadHistory();
        }
    }//GEN-LAST:event_SearchFieldActionPerformed

    private void CategorySelectionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CategorySelectionActionPerformed
        String keyword = SearchField.getText().trim();
        if (!keyword.isEmpty()) {
            searchHistory(keyword);
        } else {
            loadHistory();
        }
    }//GEN-LAST:event_CategorySelectionActionPerformed

    private void loadHistory() {
        String selectedCategory = (String) CategorySelection.getSelectedItem();
        if (selectedCategory == null) {
            selectedCategory = "All";
        }

        DefaultTableModel model = (DefaultTableModel) HistoryTable.getModel();
        model.setRowCount(0);

        try (FileReader reader = new FileReader(FILE_PATH)) {
            JSONParser parser = new JSONParser();
            JSONObject root = (JSONObject) parser.parse(reader);
            JSONArray history = (JSONArray) root.get("History");

            if (history == null) {
                return;
            }

            ArrayList<JSONObject> entries = new ArrayList<>();

            for (Object obj : history) {
                JSONObject entry = (JSONObject) obj;

                String player = (String) entry.getOrDefault("player", "");
                String category = (String) entry.getOrDefault("category", "");
                String creator = (String) entry.getOrDefault("creator", "");

                boolean canView = false;

                // Determine which role is active
                if (adminName != null && !adminName.isEmpty()) {
                    canView = true; // Admins see everything
                } else if (gameMasterName != null && !gameMasterName.isEmpty()) {
                    canView = gameMasterName.equalsIgnoreCase(creator); // Game Masters see their quizzes only
                } else if (playerName != null && !playerName.isEmpty()) {
                    canView = playerName.equalsIgnoreCase(player); // Players see their own quiz attempts
                }

                // Category filter + visibility filter
                if (canView && (selectedCategory.equals("All") || selectedCategory.equalsIgnoreCase(category))) {
                    entries.add(entry);
                }
            }

            // Sort by most recent timestamp
            entries.sort((o1, o2) -> {
                String time1 = (String) o1.getOrDefault("timestamp", "");
                String time2 = (String) o2.getOrDefault("timestamp", "");
                return time2.compareTo(time1);
            });

            // Add entries to table
            for (JSONObject entry : entries) {
                model.addRow(new Object[]{
                    entry.get("player"),
                    entry.get("quizTitle"),
                    entry.get("category"),
                    entry.get("score"),
                    entry.get("evaluation"),
                    entry.get("timestamp")
                });
            }

        } catch (IOException | ParseException e) {
            JOptionPane.showMessageDialog(this, "Failed to load history!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void populateCategorySelection() {
        try (FileReader reader = new FileReader(FILE_PATH)) { // Fixed file path issue
            JSONParser parser = new JSONParser();
            JSONObject root = (JSONObject) parser.parse(reader);
            JSONArray history = (JSONArray) root.get("History");

            Set<String> categories = new HashSet<>();
            for (Object obj : history) {
                JSONObject entry = (JSONObject) obj;
                categories.add((String) entry.get("category"));
            }

            // Add categories to the selection box
            CategorySelection.removeAllItems();
            CategorySelection.addItem("All");
            for (String category : categories) {
                CategorySelection.addItem(category);
            }
        } catch (IOException | ParseException e) {
            JOptionPane.showMessageDialog(this, "Error populating categories.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void addSearchListener() {
        SearchField.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                searchHistory(SearchField.getText().trim());
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                searchHistory(SearchField.getText().trim());
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                searchHistory(SearchField.getText().trim());
            }
        });
    }

    private void searchHistory(String keyword) {
        DefaultTableModel model = (DefaultTableModel) HistoryTable.getModel();
        model.setRowCount(0);

        try (FileReader reader = new FileReader(FILE_PATH)) {
            JSONParser parser = new JSONParser();
            JSONObject root = (JSONObject) parser.parse(reader);
            JSONArray history = (JSONArray) root.get("History");

            if (history == null) {
                return;
            }

            ArrayList<JSONObject> filtered = new ArrayList<>();

            for (Object obj : history) {
                JSONObject entry = (JSONObject) obj;

                String player = (String) entry.getOrDefault("player", "");
                String category = (String) entry.getOrDefault("category", "");
                String title = (String) entry.getOrDefault("quizTitle", "");
                String score = (String) entry.getOrDefault("score", "");
                String result = (String) entry.getOrDefault("evaluation", "");
                String timestamp = (String) entry.getOrDefault("timestamp", "");
                String creator = (String) entry.getOrDefault("creator", "");

                boolean canView = false;

                if (adminName != null && !adminName.isEmpty()) {
                    canView = true;
                } else if (gameMasterName != null && !gameMasterName.isEmpty()) {
                    canView = gameMasterName.equals(creator);
                } else if (playerName != null && !playerName.isEmpty()) {
                    canView = playerName.equals(player);
                }

                if (!canView) {
                    continue;
                }

                if (player.toLowerCase().contains(keyword.toLowerCase())
                        || category.toLowerCase().contains(keyword.toLowerCase())
                        || title.toLowerCase().contains(keyword.toLowerCase())
                        || score.toLowerCase().contains(keyword.toLowerCase())
                        || result.toLowerCase().contains(keyword.toLowerCase())
                        || timestamp.toLowerCase().contains(keyword.toLowerCase())) {
                    filtered.add(entry);
                }
            }

            filtered.sort((o1, o2) -> ((String) o2.getOrDefault("timestamp", ""))
                    .compareTo((String) o1.getOrDefault("timestamp", "")));

            for (JSONObject entry : filtered) {
                model.addRow(new Object[]{
                    entry.get("player"),
                    entry.get("quizTitle"),
                    entry.get("category"),
                    entry.get("score"),
                    entry.get("evaluation"),
                    entry.get("timestamp")
                });
            }

        } catch (IOException | ParseException e) {
            JOptionPane.showMessageDialog(this, "Search failed!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Main method for testing
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> {
            new History("AdminUser", "", "", "adminusername").setVisible(true);
        });
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BackButton;
    private javax.swing.JComboBox<String> CategorySelection;
    private javax.swing.JTable HistoryTable;
    private javax.swing.JTextField SearchField;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
